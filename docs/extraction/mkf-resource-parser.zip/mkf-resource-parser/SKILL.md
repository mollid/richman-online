---
name: mkf-resource-parser
description: Parse, inventory, and extract resources from Softstar (大宇) .mkf container files used by classic titles such as 大富翁4 / Richman 4, 仙剑奇侠传, and 轩辕剑. Use this skill whenever the user points at a *.mkf resource (e.g. help.mkf, map.mkf, Data.mkf, Effect.mkf, Panel.mkf, Speaking.mkf, MapDat.MKF), asks to disassemble / unpack / extract / analyze an MKF archive, or wants to read the BIG5 help text or decompress a compressed chunk inside one.
agent_created: true
---

# MKF Resource Parser

## Overview

MKF is Softstar's private resource archive format. A single `.mkf` holds many
chunks: uncompressed data (often BIG5 traditional-Chinese help text or binary
SMP/SPR sub-containers) and, in larger archives, chunks compressed with a
private adaptive-Huffman codec. This skill inventories every chunk and extracts
the readable ones — no external tooling required for the RAW/text path, and a
verified C decompressor (bundled) for the compressed path.

## When to use

- The user references any `*.mkf` file (game resource, modding target, etc.).
- The user says "拆解 / 解包 / 提取 / 分析" about a Softstar resource.
- The user wants the help text, card list, map data, or sprite/audio payload
  stored inside a Richman 4 / 仙剑 / 轩辕剑 archive.

## Resources

### scripts/parse_mkf.py (primary, no compiler needed)
- Pure-Python. Inventories chunks and extracts RAW BIG5 text.
- `python scripts/parse_mkf.py <file.mkf> --json inv.json` → full inventory.
- `python scripts/parse_mkf.py <file.mkf> --dump-text out.txt` → decoded text.
- Prints only a one-line status to **stderr** (stdout-safe on hosts where the
  terminal swallows output). All real output goes to the files you pass.

### scripts/mkfdec.c + scripts/mkf_decompress.c + scripts/mkf_decompress.h
- C extractor + the authoritative adaptive-Huffman decompressor (disassembled
  from the original binary, tables `table_483430` / `table_483530` intact).
- Use for **CMP** chunks. Compile once (see `references/mkf_format.md`), then:
  - `mkfdec.exe <file.mkf>` → chunk inventory table.
  - `mkfdec.exe <file.mkf> <idx> out.bin` → decompress chunk `idx` to `out.bin`.

### references/mkf_format.md
- Full container layout, SMP/SPR sub-container header, the exact
  `mkf_decompress` call contract (zero-pad `src` by 64 bytes), MSVC/MinGW build
  commands, and the environment pitfalls (broken Bash PATH, swallowed PowerShell
  stdout, BIG5 NUL bytes).

## Workflow

1. **Inventory.** Run `parse_mkf.py` with `--json` to get chunk count, offsets,
   `uncompressed_size`, `compressed_size`, and kind (RAW vs CMP). This alone
   answers "what's in this file".
2. **Extract RAW text.** For help-style archives, `--dump-text` yields the BIG5
   strings (NUL/replacement bytes already filtered). Note which chunks are
   binary SMP/SPR containers.
3. **Decompress CMP chunks.** For each CMP chunk, run `mkfdec.exe <file> <idx>
   out.bin` and inspect `out.bin` (usually SMP/SPR or an RLE bitmap). The first
   4 bytes of `out.bin` are the sub-container signature.
4. **Recurse on SMP/SPR.** If a body signature is `SMP\0`/`SPR\0`, treat it as a
   nested container using the same offset logic (see `references/mkf_format.md`).

## Critical rules

- Compare `uncompressed_size == compressed_size` to decide RAW vs CMP.
- Never hand-translate the Huffman codec into Python — compile the bundled C.
- When calling `mkf_decompress`, pass `buf_size = uncompressed_size` and
  **zero-pad the compressed source by >= 64 bytes**.
- On this Windows host, prefer PowerShell or the managed Python absolute path;
  write command output to a `.txt` file and Read it (stdout is unreliable).
