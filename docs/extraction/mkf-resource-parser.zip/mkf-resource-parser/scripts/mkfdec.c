/*
 * mkfdec.c - extract / inventory chunks from a Softstar (大宇) .mkf container.
 *
 * Build (MSVC):
 *   call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
 *   cl /O2 mkfdec.c mkf_decompress.c /Fe:mkfdec.exe
 *
 * Build (MinGW/Clang):
 *   cc -O2 mkfdec.c mkf_decompress.c -o mkfdec
 *
 * Usage:
 *   mkfdec <file.mkf>                 -> print chunk inventory to stdout
 *   mkfdec <file.mkf> <idx> [out.bin] -> extract one chunk (decompressed if needed)
 *                                        to stdout, or to out.bin if given
 *
 * Container layout (all integers little-endian):
 *   [0..3]  u32  index_table_offset  (byte offset of the chunk-offset table)
 *   chunk i data begins at offs[i]:
 *     [+0]  u32  uncompressed_size
 *     [+4]  u32  compressed_size
 *     [+8]  u32  f2 (unknown, usually 0)
 *     [+12] u32  f3 (unknown, usually 0)
 *     [+16]      chunk body (size = offs[i+1] - offs[i] - 16)
 *   index table at index_table_offset:
 *     N entries of u32 chunk offsets; N = (file_size - index_table_offset) / 4
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "mkf_decompress.h"

static int read_file(const char *fn, unsigned char **buf, size_t *len)
{
    FILE *f = fopen(fn, "rb");
    if (!f) { fprintf(stderr, "cannot open %s\n", fn); return -1; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz < 0) { fclose(f); return -1; }
    unsigned char *p = (unsigned char *)malloc((size_t)sz ? (size_t)sz : 1);
    if (fread(p, 1, (size_t)sz, f) != (size_t)sz) {
        fprintf(stderr, "read error: %s\n", fn);
        fclose(f); free(p); return -1;
    }
    fclose(f);
    *buf = p; *len = (size_t)sz;
    return 0;
}

static void get_u32(const unsigned char *p, size_t o, uint32_t *v)
{
    memcpy(v, p + o, 4);
}

int main(int argc, char **argv)
{
    if (argc < 2) {
        fprintf(stderr, "usage: %s <file.mkf> [chunk_index] [out.bin]\n", argv[0]);
        return 1;
    }
    unsigned char *data; size_t fs;
    if (read_file(argv[1], &data, &fs)) return 1;

    uint32_t index_off = 0;
    get_u32(data, 0, &index_off);
    if (index_off < 4 || index_off > fs) {
        fprintf(stderr, "bad index offset %u (file size %zu)\n", index_off, fs);
        free(data); return 1;
    }
    int n = (int)((fs - index_off) / 4);
    uint32_t *offs = (uint32_t *)(data + index_off);

    if (argc < 3) {
        printf("file=%s size=%zu index_offset=%u num_chunks=%d\n",
               argv[1], fs, index_off, n);
        for (int i = 0; i < n; i++) {
            uint32_t o = offs[i];
            uint32_t u = 0, c = 0, f2 = 0, f3 = 0;
            get_u32(data, o + 0, &u);
            get_u32(data, o + 4, &c);
            get_u32(data, o + 8, &f2);
            get_u32(data, o + 12, &f3);
            int avail = (i + 1 < n) ? ((int)offs[i + 1] - (int)o) : ((int)fs - (int)o);
            int body = avail - 16;
            char sig[5] = {0,0,0,0,0};
            if (body >= 0 && avail >= 4) memcpy(sig, data + o + 16, 4);
            const char *kind = (u == c) ? "RAW" : "CMP";
            printf("#%03d off=%-9u u=%-9u c=%-9u f2=%-6u f3=%-6u body=%-9d %s sig=%.4s\n",
                   i, o, u, c, f2, f3, body, kind, sig);
        }
        free(data);
        return 0;
    }

    int idx = atoi(argv[2]);
    if (idx < 0 || idx >= n) {
        fprintf(stderr, "chunk %d out of range 0..%d\n", idx, n - 1);
        free(data); return 1;
    }
    uint32_t o = offs[idx];
    uint32_t u = 0, c = 0;
    get_u32(data, o + 0, &u);
    get_u32(data, o + 4, &c);
    int avail = (idx + 1 < n) ? ((int)offs[idx + 1] - (int)o) : ((int)fs - (int)o);
    int body = avail - 16;
    if (body < 0) body = 0;

    FILE *out = stdout;
    if (argc >= 4) {
        out = fopen(argv[3], "wb");
        if (!out) { fprintf(stderr, "cannot write %s\n", argv[3]); free(data); return 1; }
    }

    if (u == c) {
        /* uncompressed: dump body as-is */
        if (body > 0) fwrite(data + o + 16, 1, (size_t)body, out);
    } else {
        /* compressed: feed to adaptive-Huffman decompressor */
        size_t clen = (c < (uint32_t)body) ? c : (uint32_t)body;
        unsigned char *comp = (unsigned char *)calloc(clen + 64, 1);
        if (!comp) { fprintf(stderr, "oom\n"); free(data); return 1; }
        memcpy(comp, data + o + 16, clen);
        unsigned char *obuf = (unsigned char *)malloc(u ? u : 1);
        if (!obuf) { fprintf(stderr, "oom\n"); free(comp); free(data); return 1; }
        mkf_decompress(obuf, comp, u);
        fwrite(obuf, 1, u, out);
        free(obuf); free(comp);
    }

    if (out != stdout) fclose(out);
    free(data);
    return 0;
}
