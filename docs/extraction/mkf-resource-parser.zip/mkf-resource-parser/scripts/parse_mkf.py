#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
parse_mkf.py - inventory and text-extract a Softstar (大宇) .mkf container.

The MKF container is the private resource archive used by classic Softstar
titles (大富翁4 / Richman 4, 仙剑奇侠传, 轩辕剑, ...). Layout (all
integers little-endian):

    [0..3]  u32  index_table_offset  (byte offset of the chunk-offset table)
    chunk i begins at offs[i]:
        [+0]  u32  uncompressed_size
        [+4]  u32  compressed_size
        [+8]  u32  f2 (unknown)
        [+12] u32  f3 (unknown)
        [+16]      chunk body
    index table at index_table_offset: N u32 offsets, N = (size - idx_off)//4

Chunk kinds:
    * RAW  (u == c): stored verbatim. For help-style files these are BIG5
                     traditional-Chinese help strings. Others may be binary
                     SMP/SPR sub-containers.
    * CMP  (u != c): compressed with the private adaptive-Huffman codec.
                     The C decompressor (mkf_decompress.c) is required; this
                     script only reports the sizes and does NOT decode them.

Usage:
    python parse_mkf.py <file.mkf>
    python parse_mkf.py <file.mkf> --dump-text out.txt
    python parse_mkf.py <file.mkf> --json inventory.json

Requires Python 3 (no third-party packages). Output written to files; the
script itself prints only a short status line so it is safe on hosts whose
stdout is swallowed (e.g. some Windows terminals).
"""
import sys
import os
import struct
import json

KNOWN_SIGS = {"SMP\0": "SMP image/sprite container (has its own chunk table)",
              "SPR\0": "SPR sprite container",
              "RLE\0": "RLE-compressed bitmap",
              "BM\x00": "bitmap-ish payload",
              "WAV\x00": "wave audio",
              "MID\x00": "midi audio"}


def read_u32(data, off):
    return struct.unpack_from("<I", data, off)[0]


def parse(file_path):
    with open(file_path, "rb") as f:
        data = f.read()
    fs = len(data)
    idx_off = read_u32(data, 0)
    if idx_off < 4 or idx_off > fs:
        raise ValueError("bad index offset %d (file size %d)" % (idx_off, fs))
    n = (fs - idx_off) // 4
    offs = [read_u32(data, idx_off + i * 4) for i in range(n)]

    chunks = []
    for i in range(n):
        o = offs[i]
        nxt = offs[i + 1] if i + 1 < n else fs
        csize = nxt - o  # includes 16-byte header
        u, c, f2, f3 = struct.unpack_from("<4I", data, o)
        body = csize - 16
        sig = data[o + 16:o + 20] if body >= 4 else b""
        kind = "RAW" if u == c else "CMP"
        entry = {
            "idx": i,
            "offset": o,
            "uncompressed": u,
            "compressed": c,
            "f2": f2,
            "f3": f3,
            "body_size": body,
            "kind": kind,
            "sig": sig.decode("latin1"),
        }
        chunks.append(entry)
    return fs, idx_off, n, chunks, data


def looks_like_text(b):
    """Heuristic: decode BIG5, count clean CJK/ASCII vs NUL/replacement bytes."""
    txt = b.decode("big5", errors="replace")
    chars = [ch for ch in txt if ch != "\x00"]
    if not chars:
        return False, ""
    bad = sum(1 for ch in chars if ch == "\ufffd")
    ratio = bad / len(chars)
    clean = "".join(ch for ch in chars if ch != "\ufffd").strip()
    return ratio < 0.15 and len(clean) > 0, clean


def main():
    if len(sys.argv) < 2:
        sys.stderr.write("usage: parse_mkf.py <file.mkf> [--dump-text X] [--json Y]\n")
        return 1
    file_path = sys.argv[1]
    dump_text = None
    dump_json = None
    for k in range(2, len(sys.argv)):
        if sys.argv[k] == "--dump-text" and k + 1 < len(sys.argv):
            dump_text = sys.argv[k + 1]
        elif sys.argv[k] == "--json" and k + 1 < len(sys.argv):
            dump_json = sys.argv[k + 1]

    fs, idx_off, n, chunks, data = parse(file_path)

    inv = {
        "file": os.path.basename(file_path),
        "file_size": fs,
        "index_offset": idx_off,
        "num_chunks": n,
        "chunks": chunks,
    }
    if dump_json:
        with open(dump_json, "w", encoding="utf-8") as f:
            json.dump(inv, f, ensure_ascii=False, indent=2)

    if dump_text:
        lines = []
        for e in chunks:
            if e["kind"] != "RAW":
                continue
            body = data[e["offset"] + 16: e["offset"] + 16 + max(e["body_size"], 0)]
            ok, clean = looks_like_text(body)
            if ok and clean:
                lines.append("[%02d] %s" % (e["idx"], clean))
        with open(dump_text, "w", encoding="utf-8") as f:
            f.write("\n\n".join(lines) + "\n")

    # short status to stdout (safe on hosts with swallowed stdout)
    raw = sum(1 for e in chunks if e["kind"] == "RAW")
    cmp_ = sum(1 for e in chunks if e["kind"] == "CMP")
    sys.stderr.write(
        "OK %s size=%d chunks=%d RAW=%d CMP=%d\n" % (os.path.basename(file_path), fs, n, raw, cmp_)
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
