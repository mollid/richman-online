#ifndef MKF_DECOMPRESS_H
#define MKF_DECOMPRESS_H

#include <stddef.h>
#include <stdint.h>

/* Decompress one compressed MKF chunk.
 *
 *   out_buf : destination buffer, MUST be at least `buf_size` bytes
 *   src     : compressed chunk body (the bytes after the 16-byte chunk header)
 *   buf_size: OUTPUT budget = the chunk header's `uncompressed_size` field.
 *             The stream carries its own 0xFFF end marker, so decompression
 *             stops naturally once `uncompressed_size` bytes are emitted.
 *
 * NOTE: `mkf_decompress` reads up to 4 bytes ahead of `src` (unaligned
 * uint32_t read). Callers MUST zero-pad `src` by >= 64 trailing bytes to
 * avoid reading past the end of the compressed buffer.
 */
void mkf_decompress(void *out_buf, const void *src, size_t buf_size);

#endif /* MKF_DECOMPRESS_H */
