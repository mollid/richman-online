# MKF container format (Softstar / 大宇)

Private resource archive used by classic Softstar titles: 大富翁4 (Richman 4),
仙剑奇侠传, 轩辕剑, 天使帝国, etc. The same layout appears in `*.mkf` files
(`help.mkf`, `map.mkf`, `Data.mkf`, `Effect.mkf`, `Panel.mkf`, `Speaking.mkf`,
`jump.mkf`, `MapDat.MKF`, ...).

All multi-byte integers are **little-endian**.

## Container layout

```
[0..3]   u32  index_table_offset   byte offset of the chunk-offset table
chunk i (i = 0 .. N-1) data begins at offs[i]:
   [+0]  u32  uncompressed_size
   [+4]  u32  compressed_size
   [+8]  u32  f2   (unknown; 0 in observed files)
   [+12] u32  f3   (unknown; 0 in observed files)
   [+16]      chunk body
index_table at index_table_offset:
   N entries of u32 chunk offsets
   N = (file_size - index_table_offset) / 4
```

The chunk *on disk* occupies `offs[i+1] - offs[i]` bytes, of which the first 16
are the header; the body is the remaining `offs[i+1] - offs[i] - 16` bytes. For
the last chunk use `file_size` as the end offset.

## Chunk kinds

- **RAW** — `uncompressed_size == compressed_size`. Stored verbatim.
  - help-style files: a BIG5 traditional-Chinese string (decode with codec
    `big5`, then drop NUL `0x00` and replacement `ufffd` bytes).
  - other files: a binary sub-container. The first 4 bytes of the body are a
    signature (see below).
- **CMP** — `uncompressed_size != compressed_size`. Compressed with the private
  adaptive-Huffman codec. Decode with `mkf_decompress.c` (C). Python cannot
  reliably reproduce this codec — do NOT hand-translate the Huffman tables.

## SMP / SPR sub-container (common RAW body signature)

Many RAW chunks (e.g. help.mkf chunk #0) are themselves an `SMP` or `SPR`
container. Header (`mkf.h`):

```
[0..3]   char[4]  sig         "SMP\0" or "SPR\0"
[4..7]   i32      nchunk      number of sub-chunks
[8..11]  i32      start_offset  byte offset of first sub-chunk data
[12..]   graph_st chunk_tab[0]   per-sub-chunk descriptor table
```

Treat SMP/SPR as a second-level container; recurse with the same offset logic.

## Compressed-chunk decoding (C path)

`mkf_decompress(out_buf, src, buf_size)`:
- `out_buf` — destination, size **at least `uncompressed_size`**.
- `src` — compressed chunk body (bytes after the 16-byte header).
- `buf_size` — **output budget = `uncompressed_size`**. The stream carries its
  own `0xFFF` end marker, so it stops naturally.

CRITICAL: the decompressor reads up to 4 bytes *ahead* of `src` (unaligned
`uint32_t` read). Always **zero-pad `src` by >= 64 trailing bytes** before
calling, or it may read past the buffer and crash.

Build `mkfdec.exe` (Windows, MSVC):
```
call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cl /O2 mkfdec.c mkf_decompress.c /Fe:mkfdec.exe
```

Build (MinGW / Clang / Linux):
```
cc -O2 mkfdec.c mkf_decompress.c -o mkfdec
```

## Pitfalls observed in practice

1. **Bash PATH broken on this Windows host.** The bundled `bash.exe` shim drops
   coreutils (`mkdir`, `ls`, `head`, `cd` fail). Use **PowerShell** for shell
   work, or invoke the managed Python by absolute path
   (`C:\Users\Administrator\.workbuddy\binaries\python\versions\3.13.12\python.exe`).
2. **PowerShell stdout is swallowed.** Commands exit 0 but produce no readable
   transcript output. Redirect results to a `.txt` file and read it with the
   Read tool instead of relying on the terminal echo.
3. **BIG5 text is full of NUL bytes.** Decoding a RAW text chunk yields many
   `0x00` bytes (string terminators / padding) and occasional `ufffd`. Filter
   both before treating the chunk as text; otherwise the "text" file looks
   binary.
4. **Don't hand-roll the Huffman codec.** The `table_483430` / `table_483530`
   lookup tables and the adaptive tree updates (`cfcn_45511b` etc.) are
   disassembled from the original binary. Re-implementing them in Python is
   error-prone; compile the C reference instead.
5. **`u == c` is the RAW test**, not "compressed_size field equals body size".
   Use the header `uncompressed_size == compressed_size` comparison.

## Quick triage recipe

1. `python scripts/parse_mkf.py <file> --json inv.json` → inventory + RAW/CMP split.
2. For RAW text chunks: `--dump-text out.txt` → BIG5 strings.
3. For CMP chunks: `mkfdec.exe <file> <idx> out.bin`, then inspect `out.bin`
   (often an SMP/SPR or RLE bitmap).
